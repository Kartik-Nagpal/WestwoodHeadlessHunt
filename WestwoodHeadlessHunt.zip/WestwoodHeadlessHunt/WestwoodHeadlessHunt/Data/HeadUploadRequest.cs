﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WestwoodHeadlessHunt.Data
{
    public class HeadUploadRequest
    {
        public Head head { get; set; }
        public String image { get; set; }
    }
}
