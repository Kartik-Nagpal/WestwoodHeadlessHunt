﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WestwoodHeadlessHunt.Data
{
    public class ImageData
    {
        public String image { get; set; }
        public int id { get; set; }
    }
}
