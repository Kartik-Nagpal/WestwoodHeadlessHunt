﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WestwoodHeadlessHunt.Data
{
    public class HeadGalleryResponse
    {
        public List<int> ids;
        public int total;
    }
}
